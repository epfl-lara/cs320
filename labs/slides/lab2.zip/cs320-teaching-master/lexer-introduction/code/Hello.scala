object Hello
  Std.printString("Hello " ++ "world!")
end Hello