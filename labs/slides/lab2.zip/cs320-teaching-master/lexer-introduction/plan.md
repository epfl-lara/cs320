* Global view of the pipeline
* Differences between lexer and parser
  * Lexer: string -> seq of tokens
  * Parser: seq of tokens -> tree structure
* Using silex
  * Functions
* Examples of working/non-working programs
  * Valid amy program
  * Invalid amy program that can go trough the lexer successfully
  * Invalid lexer program
* How to run the program
  * `--printTokens`
