def genConstraints(e: Expr, expected: Type)
(implicit env: Map[Identifier, Type]): List[Constraint]