object Bogus
    "Amy <3" || 5
end Bogus