object Correct
    3 + 4 == 5
end Correct