* Global view of the pipeline
* Name anaylser
  * Takes a nominal program (names are plain string, qualified names are string pairs) 
  * and returns a symbolic program, where all names have been resolved to unique Identifiers
  * Rejects programs that violate the Amy naming rules
  * Also populates the symbol table (a dictionary of symbols for the program)
* Type checker
  * Catches error in the program at compile time
  * For example adding an interger and an ADT 
  * Last stage of the compiler frontend
  * Does not modify the program only checks for (some) errors
* Implementation
  * genConstraints
    * Travers a program and generate all the typing constraints
  * solveConstraints
    * Unifies the constrains until none is left
* Tests
  * The type checker can only fail or do nothing 
  * Their is no output directly for tests
* Example 
  * Bogus 
    * Generated constraints 
    * Error message
  * Correct
    * Generated constraints
