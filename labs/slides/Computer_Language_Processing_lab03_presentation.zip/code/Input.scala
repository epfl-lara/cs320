object Example
val s: String = "Hello world";
s
end Example