def kw(string: String): Syntax[Token] = 
    elem(KeywordKind(string))

val identifier: Syntax[String] = accept(IdentifierKind) {
    case IdentifierToken(name) => name
}
lazy val definition: Syntax[ClassOrFunDef] = ???
lazy val expr: Syntax[Expr] = recursive { ??? }