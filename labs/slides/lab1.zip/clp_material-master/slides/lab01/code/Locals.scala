{
  x -> 8,
  bestFruit -> "Tomato"
}