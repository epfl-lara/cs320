object Rec_0
  fn foo_0(i_0: Int(32)): Int(32) = {
    foo_0((i_0 - 1))
  }
end Rec_0

