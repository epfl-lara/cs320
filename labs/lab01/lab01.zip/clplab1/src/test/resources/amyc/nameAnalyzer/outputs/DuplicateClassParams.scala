object ClassParams_0
  abstract class Foo_0
  case class Bar_0(v: Int(32), v: Int(32)) extends Foo_0
end ClassParams_0

