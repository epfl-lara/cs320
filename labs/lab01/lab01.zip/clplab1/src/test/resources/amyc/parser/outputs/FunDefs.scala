object FunDefs
  fn foo(): Int(32) = {
    ()
  }
  fn foo(i: Int(32)): Int(32) = {
    42
  }
  fn foo(i: I, j: Boolean, s: String, u: Unit, x: X): Type = {
    42
  }
end FunDefs
