object Locals_0
  fn foo_0(i_0: Int(32)): Int(32) = {
    i_0 match {
      case i_1 =>
        0
    }
  }
end Locals_0