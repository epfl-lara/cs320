object Locals_0
  fn foo_0(): Int(32) = {
    (if(true) {
      (
        val i_0: Int(32) =
          42;
        i_0
      )
    } else {
      (
        val i_1: Int(32) =
          42;
        i_1
      )
    })
  }
end Locals_0

