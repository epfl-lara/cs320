object ErrorToken1
  error("")
end ErrorToken1
