object CaseClassDefs
  abstract class Foo
  case class Bar() extends Foo
  case class Bar(v: Int(32)) extends Foo
  abstract class Foo
  case class Bar(v: Int(32), v: A) extends Foo
end CaseClassDefs
