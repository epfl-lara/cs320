object Parens
  -(!((1 + ((2 * 3) / (
    val x: Int(32) =
      (
        42;
        x
      );
    (((x + z match {
      case foo =>
        bar
    }) - 3) == (
      1;
      2
    ))
  )))))
end Parens

