object Factorial
  fn fact(i: Int(32)): Int(32) = {
    if (i < 2) { 1 }
    else { 
      val rec: Int(32) = fact(i-1);
      i * rec
    }
  }

  Std.printString("5! = "  ++ Std.intToString(fact(5)));
  Std.printString("10! = " ++ Std.intToString(fact(10)))
end Factorial
