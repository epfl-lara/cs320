object EmptyObject

end EmptyObject