object MinimalError
	error("")
end MinimalError
