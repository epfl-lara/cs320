#!/bin/bash
latex report
latex report
bibtex report
latex report
latex report
dvipdf report
