#!/bin/bash
rm -f report.{aux,bbl,blg,dvi,log,pdf}
