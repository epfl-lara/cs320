object Precedence
  val v: Int(32) =
    (((1 * 2) < x) || (y + 3));
  u match {
    case foo =>
      bar
  };
  (w == -((if(x) {
    y
  } else {
    z
  })))
end Precedence

