object Literals
  1;
  ();
  ();
  "Hello";
  true
end Literals
