object AssocSemicolon
  1;
  2;
  val x: Int(32) =
    z;
  val y: Int(32) =
    w;
  u
end AssocSemicolon

