object ParamAndLocal_0
  fn foo_0(i_0: Int(32)): Int(32) = {
    val i_1: Int(32) =
      (i_0 + 1);
    i_1
  }
end ParamAndLocal_0

