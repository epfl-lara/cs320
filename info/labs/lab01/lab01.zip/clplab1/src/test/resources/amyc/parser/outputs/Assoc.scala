object Assoc
  ((1 + 2) - 3);
  ((x / y) * z);
  -(42);
  ((1 < 2) <= 3);
  (true || false);
  ((1 < 2) && (2 < 3))
end Assoc
