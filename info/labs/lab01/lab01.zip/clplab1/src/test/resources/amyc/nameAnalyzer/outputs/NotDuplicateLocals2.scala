object Locals_0
  fn foo_0(): Int(32) = {
    (if(true) {
      (
        val i_0: Int(32) =
          42;
        i_0
      )
    } else {
      42 match {
        case i_1 =>
          42
      }
    })
  }
end Locals_0

