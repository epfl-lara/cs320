object ErrorToken2
  (false || error(""))
end ErrorToken2
