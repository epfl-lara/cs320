object TestLists 
  val l: L.List = L.Cons(5, L.Cons(-5, L.Cons(-1, L.Cons(0, L.Cons(10, L.Nil())))));
  Std.printString(L.toString(L.concat(L.Cons(1, L.Cons(2, L.Nil())), L.Cons(3, L.Nil()))));
  Std.printInt(L.sum(l));
  Std.printString(L.toString(L.mergeSort(l)))
end TestLists
