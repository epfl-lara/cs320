object HelloInt
  Std.printString("What is your name?");
  val name: String = Std.readString();
  Std.printString("Hello " ++ name ++ "! And how old are you?");
  val age: Int(32) = Std.readInt();
  Std.printString(Std.intToString(age) ++ " years old then.")
end HelloInt
